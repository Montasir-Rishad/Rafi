
	<div class="footerMain">
		<div class="content">
			<div class="footer-grids">
				<div class="footer one">
					<h3>More About Company</h3>
					<p>My first Platform.</p>
					<p class="adam">- MD. MONTASIR AMIN.</p>
					<div class="clear"></div>
				</div>
				<div class="footer two">
					<h3>Keep Connected</h3>
					<ul>
						<li><a class="fb" href="https://www.facebook.com/cse.bug/"><i></i>Like us on Facebook</a></li>
						<li><a class="fb1" href="https://www.youtube.com/channel/UC_fqCMzNcSLxDMwTxkSA0sw"><i></i>Subscribe on Youtube</a></li>
					</ul>
				</div>
				<div class="footer three">
					<h3>Contact Information</h3>
					<ul>
						<li>0152130**66</li>
						<li><a href="https://csebug@gmail.com">Email Us...</a></li>
					</ul>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>

	