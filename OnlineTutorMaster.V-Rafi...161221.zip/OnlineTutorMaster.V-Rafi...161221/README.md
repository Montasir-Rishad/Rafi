# Online-Tutor-System-PHP

## Summary
Hello friends, This is my online tutor management project. This is free. Anybody can use and moderate this project.

### Youtube Preview
From youtube you can see it's demo preview. Link: https://www.youtube.com/watch?v=Em6LmPH7-e0

## Platform Used
### Front-End
  (i) HTML5 <br>
  (ii) CSS3 <br>

### Back-End
  (i) PHP <br>
  (ii) MySQLi <br>

## Key Features
### Public User
(i) Search Tutor <br>
(ii) View Post <br>
(iii) Create User Account <br>

### Student/Parents User
(i) Search Tutor <br>
(ii) View Post <br>
(iii) Apply for Teacher <br>
(iv) Change Email & Password <br>
(v) Can View Previous Post with UPDATE and DELETE <br>

### Student/Parents User
(i) Search Tutor <br>
(ii) View Post <br>
(iii) Update teachers account <br>
(iv) Change Email & Password <br>
(v) Can View Previous Post with UPDATE and DELETE <br>

## Conclusion
There are also many more feature which are not in the list. Feel free to use this project
